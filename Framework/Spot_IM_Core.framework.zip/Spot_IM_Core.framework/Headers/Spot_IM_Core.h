//
//  Spot_IM_Core.h
//  Spot.IM-Core
//
//  Created by Andriy Fedin on 09/06/19.
//  Copyright © 2019 Spot.IM. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Spot_IM_Core.
FOUNDATION_EXPORT double Spot_IM_CoreVersionNumber;

//! Project version string for Spot_IM_Core.
FOUNDATION_EXPORT const unsigned char Spot_IM_CoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Spot_IM_Core/PublicHeader.h>


